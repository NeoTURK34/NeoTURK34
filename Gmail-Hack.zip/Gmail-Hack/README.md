# Gmail-Hack
#### Easy gmail hacking in python

> Я не несу ответственности за ваши действия. Скачивая программное обеспечение из этого репозитория, вы соглашаетесь с [лицензией](https://github.com/mishakorzik/Gmail-Hack/blob/main/LICENSE).

---------
## Supported systems
#### will download 1-2 minutes

* `Termux`
* `Linux`

#### Here on these systems works AllHackingTools

## Tool tested on:

* `Termux`
* `Linux`

---
<a id="installing"></a>
## Installing for termux

* `termux-setup-storage`
* `apt full-upgrade`
* `apt install git`
* `git clone https://github.com/mishakorzik/Gmail-Hack`
* `cd Gmail-Hack`
* `bash install.sh`

## Installing for linux

* `apt upgrade`
* `apt install git`
* `git clone https://github.com/mishakorzik/Gmail-Hack`
* `cd Gmail-Hack`
* `bash install.sh`

## Start Gmail-Hack

* `cd && cd Gmail-Hack && python3 Mail-Hack.py`
#### If it does not work then the command:
* `python3 Mail-Hack.py`

## Supporters
[![Stargazers repo roster for @mishakorzik/Gmail-Hack](https://reporoster.com/stars/mishakorzik/Gmail-Hack)](https://github.com/mishakorzik/Gmail-Hack/stargazers)
[![Forkers repo roster for @mishakorzik/Gmail-Hack](https://reporoster.com/forks/mishakorzik/Gmail-Hack)](https://github.com/mishakorzik/Gmail-Hack/members)


